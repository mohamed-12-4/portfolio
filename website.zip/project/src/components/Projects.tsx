import React, { useState, useEffect } from 'react';
import { ExternalLink, Github } from 'lucide-react';

interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  tags: string[];
  demoLink: string;
  githubLink: string;
}

const Projects: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    // Simulating data fetch
    const projectsData: Project[] = [
      {
        id: 1,
        title: 'E-Commerce Platform',
        description: 'A full-featured e-commerce platform with product management, cart functionality, and payment processing.',
        image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        tags: ['React', 'Node.js', 'MongoDB', 'Stripe'],
        demoLink: 'https://example.com',
        githubLink: 'https://github.com'
      },
      {
        id: 2,
        title: 'Task Management App',
        description: 'A collaborative task management application with real-time updates and team collaboration features.',
        image: 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        tags: ['React', 'Firebase', 'Material UI'],
        demoLink: 'https://example.com',
        githubLink: 'https://github.com'
      },
      {
        id: 3,
        title: 'Weather Dashboard',
        description: 'A weather dashboard that displays current and forecasted weather data for multiple locations.',
        image: 'https://images.pexels.com/photos/1118873/pexels-photo-1118873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        tags: ['JavaScript', 'API', 'CSS'],
        demoLink: 'https://example.com',
        githubLink: 'https://github.com'
      },
      {
        id: 4,
        title: 'Portfolio Website',
        description: 'A responsive portfolio website showcasing projects and skills with interactive elements.',
        image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        tags: ['React', 'TypeScript', 'Tailwind CSS'],
        demoLink: 'https://example.com',
        githubLink: 'https://github.com'
      },
      {
        id: 5,
        title: 'Blog Platform',
        description: 'A content management system for creating and managing blog posts with user authentication.',
        image: 'https://images.pexels.com/photos/261662/pexels-photo-261662.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        tags: ['React', 'Node.js', 'MongoDB'],
        demoLink: 'https://example.com',
        githubLink: 'https://github.com'
      },
      {
        id: 6,
        title: 'Chat Application',
        description: 'A real-time chat application with private messaging and group chat functionality.',
        image: 'https://images.pexels.com/photos/7014337/pexels-photo-7014337.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        tags: ['React', 'Socket.io', 'Express'],
        demoLink: 'https://example.com',
        githubLink: 'https://github.com'
      }
    ];
    
    setProjects(projectsData);
  }, []);

  // Get all unique tags
  const allTags = ['all', ...new Set(projects.flatMap(project => project.tags))];

  // Filter projects based on selected tag
  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(project => project.tags.includes(filter));

  return (
    <div className="section bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-4xl font-bold mb-12 text-center">My Projects</h2>
        
        <div className="flex justify-center mb-8 flex-wrap gap-2">
          {allTags.map(tag => (
            <button
              key={tag}
              onClick={() => setFilter(tag)}
              className={`px-4 py-2 rounded-full transition-all ${
                filter === tag 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              {tag.charAt(0).toUpperCase() + tag.slice(1)}
            </button>
          ))}
        </div>
        
        <div className="projects-grid">
          {filteredProjects.map(project => (
            <div key={project.id} className="project-card">
              <img 
                src={project.image} 
                alt={project.title} 
                className="project-image"
              />
              <div className="project-content">
                <h3 className="project-title">{project.title}</h3>
                <p className="project-description">{project.description}</p>
                <div className="project-tags">
                  {project.tags.map(tag => (
                    <span key={tag} className="project-tag">{tag}</span>
                  ))}
                </div>
                <div className="project-links">
                  <a href={project.demoLink} target="_blank" rel="noopener noreferrer" className="project-link">
                    <ExternalLink size={16} className="mr-1" /> Live Demo
                  </a>
                  <a href={project.githubLink} target="_blank" rel="noopener noreferrer" className="project-link">
                    <Github size={16} className="mr-1" /> Code
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Projects;