import React from 'react';
import { User, Mail, MapPin, Calendar, Briefcase, BookOpen } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="section bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-4xl font-bold mb-12 text-center">About Me</h2>
        
        <div className="flex flex-col md:flex-row gap-8 items-center">
          <div className="md:w-1/3">
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/1516680/pexels-photo-1516680.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Profile" 
                className="rounded-lg shadow-xl w-full max-w-sm mx-auto"
              />
              <div className="absolute -bottom-5 -right-5 bg-blue-600 text-white p-4 rounded-lg shadow-lg">
                <Briefcase size={24} />
              </div>
            </div>
          </div>
          
          <div className="md:w-2/3">
            <h3 className="text-2xl font-bold mb-4">Web Developer & UI/UX Enthusiast</h3>
            <p className="text-gray-300 mb-6">
              I'm a passionate web developer with expertise in creating interactive and responsive web applications. 
              With over 8 years of experience in the industry, I've worked on various projects ranging from small business 
              websites to complex enterprise applications.
            </p>
            <p className="text-gray-300 mb-6">
              My approach combines technical expertise with creative problem-solving to deliver solutions that not only 
              meet but exceed client expectations. I'm constantly learning and adapting to new technologies to stay at 
              the forefront of web development.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="flex items-center">
                <User className="text-blue-500 mr-3" size={20} />
                <span>John Doe</span>
              </div>
              <div className="flex items-center">
                <Mail className="text-blue-500 mr-3" size={20} />
                <span>example@example.com</span>
              </div>
              <div className="flex items-center">
                <MapPin className="text-blue-500 mr-3" size={20} />
                <span>New York, USA</span>
              </div>
              <div className="flex items-center">
                <Calendar className="text-blue-500 mr-3" size={20} />
                <span>Available for freelance</span>
              </div>
              <div className="flex items-center">
                <Briefcase className="text-blue-500 mr-3" size={20} />
                <span>8+ Years Experience</span>
              </div>
              <div className="flex items-center">
                <BookOpen className="text-blue-500 mr-3" size={20} />
                <span>Computer Science Degree</span>
              </div>
            </div>
            
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-all transform hover:scale-105">
              Download Resume
            </button>
          </div>
        </div>
        
        <div className="mt-16">
          <h3 className="text-2xl font-bold mb-6 text-center">What I Do</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-800 p-6 rounded-lg shadow-md transition-transform hover:transform hover:scale-105">
              <div className="text-blue-500 mb-4">
                <Code size={40} />
              </div>
              <h4 className="text-xl font-bold mb-2">Web Development</h4>
              <p className="text-gray-300">
                Building responsive and performant web applications using modern frameworks and technologies.
              </p>
            </div>
            
            <div className="bg-gray-800 p-6 rounded-lg shadow-md transition-transform hover:transform hover:scale-105">
              <div className="text-blue-500 mb-4">
                <Palette size={40} />
              </div>
              <h4 className="text-xl font-bold mb-2">UI/UX Design</h4>
              <p className="text-gray-300">
                Creating intuitive and engaging user interfaces with a focus on user experience and accessibility.
              </p>
            </div>
            
            <div className="bg-gray-800 p-6 rounded-lg shadow-md transition-transform hover:transform hover:scale-105">
              <div className="text-blue-500 mb-4">
                <Server size={40} />
              </div>
              <h4 className="text-xl font-bold mb-2">Backend Development</h4>
              <p className="text-gray-300">
                Developing robust server-side applications and APIs using Node.js, Express, and various databases.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Import the necessary icons
function Code(props: { size: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={props.size}
      height={props.size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="16 18 22 12 16 6"></polyline>
      <polyline points="8 6 2 12 8 18"></polyline>
    </svg>
  );
}

function Palette(props: { size: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={props.size}
      height={props.size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="13.5" cy="6.5" r=".5"></circle>
      <circle cx="17.5" cy="10.5" r=".5"></circle>
      <circle cx="8.5" cy="7.5" r=".5"></circle>
      <circle cx="6.5" cy="12.5" r=".5"></circle>
      <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"></path>
    </svg>
  );
}

function Server(props: { size: number }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={props.size}
      height={props.size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect x="2" y="2" width="20" height="8" rx="2" ry="2"></rect>
      <rect x="2" y="14" width="20" height="8" rx="2" ry="2"></rect>
      <line x1="6" y1="6" x2="6.01" y2="6"></line>
      <line x1="6" y1="18" x2="6.01" y2="18"></line>
    </svg>
  );
}

export default About;