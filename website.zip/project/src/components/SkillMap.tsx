import React, { useState, useEffect } from 'react';
import { Code, Database, Server, Globe, Palette, Terminal } from 'lucide-react';

interface Skill {
  id: number;
  name: string;
  level: number;
  category: string;
  icon: React.ReactNode;
}

const SkillMap: React.FC = () => {
  const [skills, setSkills] = useState<Skill[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [isAnimating, setIsAnimating] = useState<boolean>(false);

  useEffect(() => {
    // Simulating data fetch
    const skillsData: Skill[] = [
      { id: 1, name: 'React', level: 90, category: 'frontend', icon: <Code size={32} /> },
      { id: 2, name: 'JavaScript', level: 95, category: 'frontend', icon: <Code size={32} /> },
      { id: 3, name: 'TypeScript', level: 85, category: 'frontend', icon: <Code size={32} /> },
      { id: 4, name: 'HTML/CSS', level: 90, category: 'frontend', icon: <Globe size={32} /> },
      { id: 5, name: 'Node.js', level: 80, category: 'backend', icon: <Server size={32} /> },
      { id: 6, name: 'Express', level: 75, category: 'backend', icon: <Server size={32} /> },
      { id: 7, name: 'MongoDB', level: 70, category: 'database', icon: <Database size={32} /> },
      { id: 8, name: 'SQL', level: 65, category: 'database', icon: <Database size={32} /> },
      { id: 9, name: 'UI/UX Design', level: 60, category: 'design', icon: <Palette size={32} /> },
      { id: 10, name: 'Git', level: 85, category: 'tools', icon: <Terminal size={32} /> },
      { id: 11, name: 'Docker', level: 70, category: 'tools', icon: <Terminal size={32} /> },
      { id: 12, name: 'AWS', level: 65, category: 'tools', icon: <Server size={32} /> },
    ];
    
    setSkills(skillsData);
  }, []);

  const categories = [
    { id: 'all', name: 'All Skills' },
    { id: 'frontend', name: 'Frontend' },
    { id: 'backend', name: 'Backend' },
    { id: 'database', name: 'Database' },
    { id: 'design', name: 'Design' },
    { id: 'tools', name: 'Tools' },
  ];

  const filterSkills = (category: string) => {
    setIsAnimating(true);
    setActiveCategory(category);
    setTimeout(() => setIsAnimating(false), 500);
  };

  const filteredSkills = activeCategory === 'all' 
    ? skills 
    : skills.filter(skill => skill.category === activeCategory);

  return (
    <div className="section bg-gray-900 py-16">
      <h2 className="section-title text-4xl font-bold mb-12 text-center">Skills & Expertise</h2>
      
      <div className="flex justify-center mb-8 flex-wrap gap-2">
        {categories.map(category => (
          <button
            key={category.id}
            onClick={() => filterSkills(category.id)}
            className={`px-4 py-2 rounded-full transition-all ${
              activeCategory === category.id 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {category.name}
          </button>
        ))}
      </div>
      
      <div className={`skill-map transition-opacity duration-500 ${isAnimating ? 'opacity-0' : 'opacity-100'}`}>
        {filteredSkills.map(skill => (
          <div key={skill.id} className="skill-node">
            <div className="skill-icon">{skill.icon}</div>
            <h3 className="skill-name text-lg">{skill.name}</h3>
            <div className="skill-level">
              <div 
                className="skill-progress" 
                style={{ width: `${skill.level}%` }}
              ></div>
            </div>
            <div className="mt-2 text-sm text-gray-400">{skill.level}%</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SkillMap;