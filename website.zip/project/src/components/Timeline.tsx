import React, { useEffect, useState } from 'react';

interface TimelineItem {
  id: number;
  date: string;
  title: string;
  description: string;
  position: 'left' | 'right';
}

const Timeline: React.FC = () => {
  const [timelineItems, setTimelineItems] = useState<TimelineItem[]>([]);
  const [visibleItems, setVisibleItems] = useState<number[]>([]);

  useEffect(() => {
    // Simulating data fetch
    const items: TimelineItem[] = [
      {
        id: 1,
        date: '2023 - Present',
        title: 'Senior Software Developer',
        description: 'Leading development of enterprise applications using React, Node.js, and AWS. Implemented CI/CD pipelines and mentored junior developers.',
        position: 'left'
      },
      {
        id: 2,
        date: '2020 - 2023',
        title: 'Full Stack Developer',
        description: 'Developed and maintained web applications using React, TypeScript, and Express. Collaborated with UX designers to implement responsive designs.',
        position: 'right'
      },
      {
        id: 3,
        date: '2018 - 2020',
        title: 'Frontend Developer',
        description: 'Created interactive user interfaces using React and Redux. Optimized application performance and implemented responsive designs.',
        position: 'left'
      },
      {
        id: 4,
        date: '2016 - 2018',
        title: 'Web Developer',
        description: 'Built and maintained websites using HTML, CSS, JavaScript, and PHP. Worked closely with designers to implement pixel-perfect designs.',
        position: 'right'
      },
      {
        id: 5,
        date: '2014 - 2016',
        title: 'Junior Developer',
        description: 'Started my career working on frontend development with HTML, CSS, and jQuery. Assisted senior developers with various projects.',
        position: 'left'
      }
    ];
    
    setTimelineItems(items);

    // Animate items into view as user scrolls
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = Number(entry.target.getAttribute('data-id'));
          setVisibleItems(prev => [...prev, id]);
        }
      });
    }, { threshold: 0.2 });

    setTimeout(() => {
      document.querySelectorAll('.timeline-item').forEach(item => {
        observer.observe(item);
      });
    }, 100);

    return () => observer.disconnect();
  }, []);

  return (
    <div className="section bg-gray-900">
      <h2 className="section-title text-4xl font-bold mb-12 text-center">My Journey</h2>
      <div className="timeline-container">
        <div className="timeline">
          {timelineItems.map((item) => (
            <div 
              key={item.id}
              data-id={item.id}
              className={`timeline-item ${item.position} ${visibleItems.includes(item.id) ? 'animate-fadeIn' : 'opacity-0'}`}
              style={{ 
                transitionDelay: `${(item.id - 1) * 200}ms`,
                animationDelay: `${(item.id - 1) * 200}ms` 
              }}
            >
              <div className="timeline-content">
                <div className="timeline-date">{item.date}</div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-gray-300">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Timeline;