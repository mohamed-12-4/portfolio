import React from 'react';
import { BookOpen, Award, Calendar } from 'lucide-react';

interface EducationItem {
  id: number;
  degree: string;
  institution: string;
  location: string;
  period: string;
  description: string;
}

interface CertificationItem {
  id: number;
  name: string;
  issuer: string;
  date: string;
  description: string;
}

const Education: React.FC = () => {
  const educationItems: EducationItem[] = [
    {
      id: 1,
      degree: 'Master of Science in Computer Science',
      institution: 'Stanford University',
      location: 'Stanford, CA',
      period: '2016 - 2018',
      description: 'Specialized in Artificial Intelligence and Web Technologies. Completed thesis on "Optimizing React Applications for Performance".'
    },
    {
      id: 2,
      degree: 'Bachelor of Science in Computer Science',
      institution: 'MIT',
      location: 'Cambridge, MA',
      period: '2012 - 2016',
      description: 'Graduated with honors. Focused on software engineering and web development. Participated in various hackathons and coding competitions.'
    }
  ];

  const certifications: CertificationItem[] = [
    {
      id: 1,
      name: 'AWS Certified Solutions Architect',
      issuer: 'Amazon Web Services',
      date: 'January 2023',
      description: 'Validated expertise in designing and deploying scalable systems on AWS.'
    },
    {
      id: 2,
      name: 'Professional React Developer',
      issuer: 'Meta',
      date: 'June 2022',
      description: 'Comprehensive certification covering advanced React concepts, state management, and performance optimization.'
    },
    {
      id: 3,
      name: 'Full Stack Web Development',
      issuer: 'Udacity',
      date: 'March 2021',
      description: 'Completed intensive program covering frontend and backend technologies including React, Node.js, and databases.'
    },
    {
      id: 4,
      name: 'UI/UX Design Fundamentals',
      issuer: 'Google',
      date: 'November 2020',
      description: 'Learned principles of user interface design, user experience, and design thinking.'
    }
  ];

  return (
    <div className="section bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-4xl font-bold mb-12 text-center">Education & Certifications</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Education Section */}
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <BookOpen className="mr-3 text-blue-500" size={24} />
              Academic Education
            </h3>
            
            <div className="space-y-8">
              {educationItems.map(item => (
                <div key={item.id} className="bg-gray-800 rounded-lg p-6 shadow-lg transition-transform hover:transform hover:scale-105">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="text-xl font-bold text-blue-400">{item.degree}</h4>
                    <span className="bg-blue-600 text-white text-sm px-3 py-1 rounded-full flex items-center">
                      <Calendar size={14} className="mr-1" />
                      {item.period}
                    </span>
                  </div>
                  <div className="mb-4">
                    <div className="text-lg">{item.institution}</div>
                    <div className="text-gray-400">{item.location}</div>
                  </div>
                  <p className="text-gray-300">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
          
          {/* Certifications Section */}
          <div>
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <Award className="mr-3 text-blue-500" size={24} />
              Professional Certifications
            </h3>
            
            <div className="space-y-4">
              {certifications.map(cert => (
                <div key={cert.id} className="bg-gray-800 rounded-lg p-5 shadow-lg transition-all hover:bg-gray-750">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-lg font-bold">{cert.name}</h4>
                    <span className="text-gray-400 text-sm">{cert.date}</span>
                  </div>
                  <div className="text-blue-400 mb-2">{cert.issuer}</div>
                  <p className="text-gray-300 text-sm">{cert.description}</p>
                </div>
              ))}
            </div>
            
            {/* Additional Skills */}
            <div className="mt-8 bg-gray-800 rounded-lg p-6 shadow-lg">
              <h3 className="text-xl font-bold mb-4">Additional Education</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <div className="bg-blue-600 p-1 rounded-full mr-3 mt-1">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                  <div>
                    <span className="font-medium">Numerous Online Courses</span>
                    <p className="text-gray-400 text-sm">Completed courses on platforms like Coursera, Udemy, and Pluralsight in various technologies.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-600 p-1 rounded-full mr-3 mt-1">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                  <div>
                    <span className="font-medium">Technical Workshops</span>
                    <p className="text-gray-400 text-sm">Participated in workshops on cloud computing, DevOps, and modern web development.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-600 p-1 rounded-full mr-3 mt-1">
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                  </div>
                  <div>
                    <span className="font-medium">Industry Conferences</span>
                    <p className="text-gray-400 text-sm">Regularly attend tech conferences to stay updated with the latest trends and technologies.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Education;